﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shared
{
    /// <summary>
    /// OperationType Class
    /// </summary>
    public static class OperationType
    {
        //add the mappings for operation type and its corresponding sql query text
        public static readonly Dictionary<String, String> Map
            = new Dictionary<String, String>
            {
                {Read, OperationText.Read},
                {ReadByCategory, OperationText.ReadByCategory},
                {ReadById, OperationText.ReadById},
                {UpdateById, OperationText.UpdateById },
                {DeleteById, OperationText.DeleteById },

                {Login, OperationText.Login },
                {Register, OperationText.Register }
            };

        public const String Read = "Read";
        public const String ReadByCategory = "ReadByCategory";
        public const String ReadById = "ReadById";
        public const String UpdateById = "UpdateById";
        public const String DeleteById = "DeleteById";
        public const String Login = "Login";
        public const String Register = "Register";
    }

    /// <summary>
    /// Class to provide custom exception messages
    /// </summary>
    public static class Exceptions
    {
        public const String Error = "Some error has occured";
    }

    /// <summary>
    /// OperationText Class
    /// </summary>
    public static class OperationText
    {
        public const String Read = "SELECT * FROM vwBookUserMapping";
        public const String ReadByCategory = "SELECT * FROM vwBookUserMapping WHERE Category = @category";
        public const String ReadById = "SELECT * FROM vwBookUserMapping WHERE Id = @id";
        public const String UpdateById = "INSERT INTO tblBookUserMapping VALUES (@id,@userid,@sub)";
        public const String DeleteById = "DELETE FROM tblBookUserMapping WHERE BookId = @id AND UserId = @userid";

        public const String Login = "SELECT *FROM tblUser WHERE UserName=@username AND Password=@password";
        public const String Register = "INSERT INTO tblUser VALUES (@firstname,@lastname,@username,@password,@email)";
        
    }

}
