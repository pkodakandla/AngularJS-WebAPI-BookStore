﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.SessionState;

using Controller;
using Shared;
using Shared.Models;

namespace BookStore
{
    public class BookController : ApiController
    {
        /// <summary>
        /// Get all books
        /// </summary>
        /// <returns></returns>
        public List<BookModel> GetBooks()
        {
            CommonController commonController = HttpContext.Current.Session["CommonController"] as CommonController;
            List<BookModel> returnData = commonController.ExecuteOperation(OperationType.Read, null) as List<BookModel>;

            return returnData;
        }

        /// <summary>
        /// Get book by its id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public List<BookModel> GetBookById(Int32 id)
        {
            CommonController commonController = HttpContext.Current.Session["CommonController"] as CommonController;
            Dictionary<String, Object> data = new Dictionary<String, Object>();
            data.Add("id", id);
            List<BookModel> returnData = commonController.ExecuteOperation(OperationType.ReadById, data) as List<BookModel>;

            return returnData;
        }

        /// <summary>
        /// All Post Methods.
        /// </summary>
        /// <param name="category"></param>
        /// <returns></returns>
        public List<BookModel> Post([FromBody] String values)
        {
            List<BookModel> returnData = new List<BookModel>();
            CommonController commonController = HttpContext.Current.Session["CommonController"] as CommonController;
            Dictionary<String, Object> data = new Dictionary<String, Object>();

            switch (values.Split(' ')[0])
            {
                case "Search":
                    data.Add("category", values.Split(' ')[1]);
                    returnData = commonController.ExecuteOperation(OperationType.ReadByCategory, data) as List<BookModel>;
                    break;
                case "Update":
                    data.Add("id", values.Split(' ')[1]);
                    data.Add("userid", 1);
                    data.Add("sub", values.Split(' ')[2]);
                    returnData = commonController.ExecuteOperation(OperationType.UpdateById, data) as List<BookModel>;
                    break;
                case "Login":
                    data.Add("username", values.Split(' ')[1]);
                    data.Add("password", values.Split(' ')[2]);
                    returnData = commonController.ExecuteOperation(OperationType.Login, data) as List<BookModel>;
                    break;
                case "Register":
                    
                    data.Add("firstname", values.Split(' ')[1]);
                    data.Add("lastname", values.Split(' ')[2]);
                    data.Add("email", values.Split(' ')[3]);
                    data.Add("username", values.Split(' ')[4]);
                    data.Add("password", values.Split(' ')[5]);

                    returnData = commonController.ExecuteOperation(OperationType.Register, data) as List<BookModel>;
                    break;
            }

             return returnData;
        }  
    }
}